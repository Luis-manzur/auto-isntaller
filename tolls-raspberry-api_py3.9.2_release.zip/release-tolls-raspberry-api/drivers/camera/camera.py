"""Device connection and operations"""
import base64
import os
import time
from threading import Event, Thread
from time import sleep

from multipledispatch import dispatch

import utils as project_utils
from device_module.device import BaseDevice
from dispatcher_module.event_dispatcher import messages
from dispatcher_module.events import camera_events
from dispatcher_module.events import device_events
from dispatcher_module.events.camera_events import CameraStateMachineEvent
from drivers.camera import consts as camera_consts
from logger import get_logger
from modules import consts as modules_consts
from runtime_cache import consts as runtime_const
from runtime_cache import runtime_data_cache
from state_machine.camera_state_machine import CameraStateMachine
from tolls_raspberry_proj import settings
from modules import get_state

logger = get_logger()

if not settings.SIMULATE_PORTS:
    import cv2


class Camera(BaseDevice):
    device_automata = None
    _status = camera_consts.DISCONNECTED
    _stop_signal = None
    code = None

    device_status_thread = None
    antenna_state_thread = None
    serial_conn = None
    state_machine = None

    camera_url = None
    template_camera_path = None
    return_code = None
    camera_connection = None
    user = None
    password = None

    def __init__(self, name, uid, config):
        super().__init__(name, uid, config)
        self.reading = False
        self.message_view_data = None
        self.message_view_state = None

        self.current_operation = {}
        self.is_valid_config = None
        self.enable = False
        self.device_name = name

        self.timeout = 100
        self.is_valid_config = True
        self.request_tries = 0

        state_machine = config.get('bsm', 'camera-bsm.json')
        self.is_valid_config = True

        # if not settings.SIMULATE_PORTS and settings.CAMERA_ACTIVE:
        # noinspection PyUnresolvedReferences

        try:
            bsm_def = project_utils.load_json(os.path.join(settings.CONFIG_PATH, state_machine))
        except Exception as e:
            logger.error(
                f'ERROR loading the antenna bsm config. The exception is {e}')
            bsm_def = {}

        self.device_automata = CameraStateMachine(self, bsm_def)

    def init_module(self):
        super(Camera, self).init_module()

    @property
    def is_enable(self):
        return self.enable

    @is_enable.setter
    def is_enable(self, value):
        self.enable = value

    def on_module_start(self):
        super(Camera, self).on_module_start()
        self._stop_signal = Event()

        try:
            if not settings.SIMULATE_PORTS and settings.CAMERA_ACTIVE:
                self.device_status_thread = Thread(
                    name=f'{self.device_name}', target=self.serial_camera_worker)
                sleep(0.2)
                self.device_status_thread.start()

                self.camera_url = settings.CAMERA_URL
                self.user = settings.CAMERA_USER
                self.password = settings.CAMERA_PASSWORD

        except Exception as msg:
            print(f'Reader not initialized due to ${msg}')
            return False
        self.device_automata.dispatch(camera_consts.EV_INIT, [])
        return True

    def on_module_stop(self):
        super(Camera, self).on_module_stop()
        self.module_status = modules_consts.MOD_ST_STOPPED

        if self._stop_signal:
            self._stop_signal.set()

            if self.device_status_thread:
                self.device_status_thread.join()
                self.device_status_thread = None
            else:
                time.sleep(0.8)

            self._stop_signal = None
        else:
            logger.error(messages.MODULE_WAS_STOPPED_ALREADY_FMT.format(self.device_name))

        return True

    def set_message_view_data(self, message, message_type):
        # will be displayed on the /processing and /error pages and will be auto-reset on changing to a different state
        self.message_view_data = {
            'message': message,
            'type': message_type
        }

        # noinspection PyUnresolvedReferences
        self.message_view_state = self.state

    def on_enter_init(self, event_data):
        pass

    # noinspection PyUnusedLocal
    def on_enter_disabled(self, event_data):
        self.device_automata.dispatch(camera_consts.EV_OPERATIVE)

    # noinspection PyUnusedLocal
    def on_camera_added(self):
        self._status = camera_consts.CONNECTED
        device_info = {
            'device_name': self.device_name,
            'device_type': self.device_type
        }
        # noinspection PyTypeChecker
        self.post_event(device_events.DeviceConnectedEvent(
            self.module_uid, device_info))

    def on_camera_removed(self):
        self._status = camera_consts.DISCONNECTED
        payload = {}
        # noinspection PyTypeChecker
        self.device_automata.dispatch(
            camera_events.CameraStateMachineRemoved, payload)
        device_info = {
            'device_name': self.device_name,
            'device_type': self.device_type
        }
        self.post_event(device_events.DeviceDisconnectedEvent(self.module_uid, device_info))

    def update_device_status(self, data):
        # noinspection PyUnresolvedReferences
        pass

    def on_display_message(self, message_data):
        pass

    def on_message_time_out(self, event_data):
        pass

    def on_operation_success(self, result):
        pass

    def on_enter_waiting_image(self):
        pass

    def on_enter_take_image(self, lane_code):
        if not settings.SIMULATE_PORTS and settings.CAMERA_ACTIVE and get_state('BOOTH LOOP') == 'st_vehicle_detected' and get_state('GATE LOOP') == 'st_non_vehicle_detected':
            try:
                cap = cv2.VideoCapture(settings.CAMERA_URL)
                logger.info('Connecting to camera')

                if not cap.isOpened():
                    logger.error("Failed to open the RTSP stream.")
                    exit()

                # Read a frame from the stream
                ret, frame = cap.read()

                # Check if a frame was retrieved successfully
                if not ret:
                    logger.error("Failed to retrieve a frame from the stream.")
                    exit()

                # Save the frame as an image
                self.device_automata.dispatch(camera_consts.EV_PROCESS_IMAGE, frame)
                logger.info('Frame taken')
                # Release the resources
                cap.release()
                logger.info('camera disconnected')

            except Exception as ex:
                raise Exception(f'Error in Camera module, could not connect to the camera: {ex}')
                self.device_automata.dispatch(camera_consts.EV_DISABLE, [])
        else:
            self.device_automata.dispatch(camera_consts.EV_DISABLE, [])

    def on_enter_process_image(self, frame):
        try:
             # Convert the frame to base64 encoding
            _, buffer = cv2.imencode('.jpg', frame)
            base64_data = base64.b64encode(buffer)
            base64_image = base64_data.decode('utf-8')
            runtime_data_cache.lpush(name=runtime_const.PLATE_IMAGE_QUEUE, data=base64_image)
            logger.info('Frame saved')

        except Exception as ex:
            logger.error(f'Error in Camera module while processing the image : {ex}')
        
        finally:
            self.device_automata.dispatch(camera_consts.EV_DISABLE, [])

    # Events

    @dispatch(CameraStateMachineEvent)
    def do_dispatch_event(self, event):
        request_data = event.data
        trigger = request_data.get(camera_consts.TRIGGER)
        if self.device_automata.dispatch(trigger, request_data):
            logger.debug(f'Event --> {event.name} dispatched')

    def serial_camera_worker(self, interval=0.25):
        sleep(0.2)

        while self._stop_signal and not self._stop_signal.is_set():
            # noinspection PyUnresolvedReferences
            if self.state == camera_consts.ST_IDLE:
                response = None
                status = camera_consts.DISCONNECTED if response is camera_consts.DEVICE_NOT_CONNECTED \
                    else camera_consts.CONNECTED
                if status != self._status:
                    self._status = status
                    if self._status == camera_consts.CONNECTED:
                        self.on_camera_added()
                    else:
                        self.on_camera_removed()

            self._stop_signal.wait(interval)

