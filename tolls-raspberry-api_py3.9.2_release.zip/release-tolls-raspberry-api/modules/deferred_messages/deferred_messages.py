import base64
import json
import os
import threading
import time
import uuid
from typing import Optional

import zlib

import response_codes
import tolls_raspberry_proj.settings as settings
from api_gate.models import SecureMessage
from dispatcher_module.event_dispatcher.api_call_and_wait import api_call_and_wait
from logger import get_logger
from modules.base_module import BaseModule
from modules.deferred_messages import messages_consts
from runtime_cache import consts as runtime_const
from runtime_cache import runtime_data_cache

logger = get_logger()

PING_INTERVAL = settings.PING_INTERVAL_IN_MINUTES * 60
BLACK_LIST_INTERVAL = settings.BLACKLIST_INTERVAL_IN_MINUTES * 60
DELAY_AFTER_SEND_SUCCESS = 0.2
DELAY_AFTER_SEND_FAILURE = 5
DELAY_IF_NO_MESSAGES = 1


class DeferredMessages(BaseModule):
    is_config_valid = False
    _db_path = None
    _stop_signal = None
    _queue_thread = None
    _inter_thread_queue = None

    def on_module_start(self):
        """
        Initialize the module by checking the database, the thread worker, etc.
        :return: bool. True if the whole initialization was successful, False otherwise
        """
        if self._queue_thread:
            # module is already running
            return self.is_config_valid

        self.is_config_valid = self._create_processing_threads()
        return self.is_config_valid

    def on_module_stop(self):
        """
        Set the stop signal for the thread worker and wait for the thread to join. This gets called when the
        dispatch module is being stopped.
        :return: bool. True
        """
        if self._queue_thread:
            self._stop_signal.set()
            self._queue_thread.join()

            self._stop_signal = None
            self._queue_thread = None
            return True

        else:
            # module was not running
            return False

    def _create_processing_threads(self):
        """
        Create and start the thread workers.
        There are two workers involved on the secure messages process:
        - The first one, processing the inter-thread queue and storing the messages on the database to make
          the messages persistent across app restarts. This one is fast because it only populates the database

        - The second one, picking up the next message from the db and trying to send the message via ApiCaller.
          This one can be slow and receive timeouts, depending on the network conditions. This one also has the logic
          to retry messages until they are sent to the remote server, one day in the future ;)
        See the functions "_queue_thread_worker" and "_database_thread_worker" for more details.

        :return: bool. True.
        """
        self._stop_signal = threading.Event()

        # Inter-thread queue processor
        self._queue_thread = threading.Thread(target=self._queue_thread_worker, daemon=False)
        self._queue_thread.start()

        return True

    def is_queue_thread_running(self):
        """
        Returns whether the thread processing the 'inter-thread queue' is alive and running.
        This function is used inside the "_queue_worker" to evaluate the running condition.

        :return: bool. True if the thread should be running, False otherwise
        """
        return bool(self._queue_thread and self._queue_thread.is_alive()) and not self._stop_signal.is_set()

    @staticmethod
    def _extract_next_db_message() -> Optional[SecureMessage]:
        """
        Retrieves the next message to process from the queue. The criteria to pick the next message is
        the least recent timestamp.

        :return: The next message to process or None if there is the queue is empty or there was an error
        """
        try:
            result = SecureMessage.objects.all().order_by('-created_on').first()
        except Exception as ex:
            logger.error(f'Error in _extract_next_db_message: {ex}')
            result = None

        return result

    def _queue_thread_worker(self):
        """
        The thread worker that checks the inter-thread queue at regular intervals for messages to post to the database.
        """
        logger.debug('Deferred thread worker started')

        tasks = {
            'ping': {'time': time.time(), 'task': self.ping_to_regional, 'interval': PING_INTERVAL},
            'black_list': {'time': time.time(), 'task': self.black_list, 'interval': BLACK_LIST_INTERVAL}

        }

        while self.is_queue_thread_running():
            now = time.time()

            for task in tasks:
                if now >= tasks[task]['time']:
                    tasks[task]['task']()
                    tasks[task]['time'] = now + tasks[task]['interval']

            msg = self._extract_next_db_message()
            if msg:
                if self._process_message(msg):
                    self._stop_signal.wait(DELAY_AFTER_SEND_SUCCESS)
                else:
                    self._stop_signal.wait(DELAY_AFTER_SEND_FAILURE)
            else:
                self._stop_signal.wait(DELAY_IF_NO_MESSAGES)

        logger.debug('Deferred thread worker finished')

    @staticmethod
    def _process_message(msg: SecureMessage) -> bool:
        """
        Process a message. This is, try to send it via the ApiCaller. If this function succeeds, the message will be
        removed from the database queue.

        :param msg: The message to process as returned by the method "_extract_next_db_message"
        :return: True if the message has been processed, False otherwise
        """
        success = False

        try:
            api_name = messages_consts.MESSAGE_TYPE_TO_API_NAME.get(msg.message_type)
            if not api_name:
                raise Exception(f'Invalid message type "{msg.message_type}"')

            message_payload = json.loads(msg.json_payload)
            prepared_data = {
                'message_id': str(msg.message_id),
                'node_id': msg.node_id,
                'parent_site_id': msg.parent_site_id,
                'company_id': msg.company_id,
                'shift_uuid': msg.shift_uuid,
                'employee_id': msg.employee_id,
                'work_shift': msg.work_shift,
                'work_period': msg.work_period,
                'created_on': msg.created_on.strftime('%Y-%m-%d %H:%M:%S'),
                'message_payload': message_payload,
            }
            if settings.SERVER_NAME == 'fontur':
                success, return_data = api_call_and_wait(api_name, prepared_data)
            elif settings.SERVER_NAME == 'arcorp':
                success, return_data = api_call_and_wait(api_name, message_payload)
            if success:
                if type(return_data) == dict and ('return_code' in return_data):
                    return_code = return_data.get('return_code')
                    if return_code == response_codes.SUCCESS:
                        logger.info(f'Secure message succeeded for api_name="{api_name}"')
                    else:
                        logger.warning(f'Secure message succeeded but returned an error: '
                                       f'api_name="{api_name}", return_code={return_code}')
                else:
                    logger.info(f'Secure message succeeded for api_name="{api_name}" but did not return a dict')

            else:
                logger.error(f'Deferred message call api_name="{api_name}" failed')

        except Exception as e:
            logger.error(f'Error in message_manager._process_message: {e}')

        if success:
            msg.delete()

        return success

    @staticmethod
    def generate_message_id():
        """Generate an unique packet id."""
        return str(uuid.uuid1())

    @staticmethod
    def post_deferred_message(message_type: str, message_payload: Optional[dict]):
        """
        Queue a new message to be safely sent in the future. The processing thread will pick it up from the queue and
        insert it on the db table to make it persistent across restarts of the app.

        :param message_type: Any of the message types defined in the message_consts module
        :param message_payload: The data to be sent as part of the call
        """

        # Validate node info
        if settings.SERVER_NAME == 'fontur':
            return DeferredMessages.fontur_deferred_message(message_type, message_payload)
        elif settings.SERVER_NAME == 'arcorp':
            return DeferredMessages.arcorp_deferred_message(message_type, message_payload)

    @staticmethod
    def arcorp_deferred_message(message_type: str, message_payload: Optional[dict]):
        try:
            message_id = DeferredMessages.generate_message_id()
            api_name = messages_consts.MESSAGE_TYPE_TO_API_NAME.get(message_type)
            if not api_name:
                raise Exception(f'Invalid message type "{message_type}"')

            message_payload['flagged'] = 1 if message_payload['flagged'] else 0
            del message_payload['plate_image']
            del message_payload['payment_method']
            del message_payload['requested_by']

            json_payload = json.dumps(message_payload, default=str)

            msg = SecureMessage(message_type=message_type, message_id=message_id, json_payload=json_payload)
            msg.save()
            return True

        except Exception as ex:
            logger.error(f'Error in post_deferred_message: {ex}')
            return False

    @staticmethod
    def fontur_deferred_message(message_type: str, message_payload: Optional[dict]):

        try:
            node_info = runtime_data_cache.get_variable(runtime_const.NODE_INFO)
            node_id = node_info.get('id') if type(node_info) == dict else None
        except Exception as ex:
            logger.error(f'Error in post_deferred_message while getting the node_id: {ex}')
            return False

        if not node_id:
            logger.error(f'Error in post_deferred_message: not a valid node_id')
            return False

        # Validate site info
        try:
            toll_site_info = runtime_data_cache.get_variable(runtime_const.TOLL_SITE_INFO)
            parent_site_id = toll_site_info.get('id') if type(toll_site_info) == dict else None
        except Exception as ex:
            logger.error(f'Error in post_deferred_message while getting the parent_site_id: {ex}')
            return False

        if not parent_site_id:
            logger.error(f'Error in post_deferred_message: not a valid parent_site_id')
            return False

        # Validate company info
        try:
            company_info = runtime_data_cache.get_variable(runtime_const.COMPANY_INFO)
            company_id = company_info.get('id') if type(company_info) == dict else None
        except Exception as ex:
            logger.error(f'Error in post_deferred_message while getting the company_id: {ex}')
            return False

        if not company_id:
            logger.error(f'Error in post_deferred_message: not a valid company_id')
            return False

        # Validate employee info
        try:
            employee_info = runtime_data_cache.get_variable(runtime_const.TOLL_OPERATOR_INFO)
            employee_id = employee_info.get('id') if type(employee_info) == dict else None
        except Exception as ex:
            logger.error(f'Error in post_deferred_message while getting the employee_id: {ex}')
            return False

        if not employee_id:
            logger.error(f'Error in post_deferred_message: not a valid employee_id')
            return False

        # Create the message item
        try:
            api_name = messages_consts.MESSAGE_TYPE_TO_API_NAME.get(message_type)
            if not api_name:
                raise Exception(f'Invalid message type "{message_type}"')

            message_id = DeferredMessages.generate_message_id()
            work_shift = runtime_data_cache.get_variable(runtime_const.WORK_SHIFT)
            work_period = runtime_data_cache.get_variable(runtime_const.WORK_PERIOD)
            json_payload = json.dumps(message_payload, default=str)
            shift_uuid = runtime_data_cache.get_variable(runtime_const.SHIFT_UUID) if runtime_data_cache.get_variable(runtime_const.SHIFT_UUID) else ""
            msg = SecureMessage(message_type=message_type, message_id=message_id,
                                node_id=node_id, parent_site_id=parent_site_id,
                                company_id=company_id, employee_id=employee_id,
                                work_shift=work_shift, work_period=work_period, shift_uuid=shift_uuid,
                                json_payload=json_payload)
            msg.save()

            return True

        except Exception as ex:
            logger.error(f'Error in post_deferred_message: {ex}')
            return False

    @staticmethod
    def ping_to_regional():
        status = {'node_code': settings.NODE_CODE}
        success, result = api_call_and_wait('venvias/ping', status)
        if not success:
            logger.error('Error sending ping to venvias')
        else:
            logger.info('Success sending ping to venvias')

    def black_list(self):
        try:
            params = {'ticketing-machine': True}
            success, result = api_call_and_wait('venvias/black_list', params)
            json_location = os.path.join(settings.CONFIG_PATH, 'login_data/blacklist.json')
            if success:
                black_list = self.decode_and_decompress(result['data'])
                with open(json_location, "w") as file:
                    json.dump(black_list, file)
                logger.info('Successfully retrieved black list')
            else:
                with open(json_location, "r") as file:
                    black_list = json.load(file)
                logger.error('Failed to retrieve black list')
            runtime_data_cache.set_variable(runtime_const.BLACK_LIST, black_list)
        except Exception as e:
            logger.exception('Error retrieving black list: %s', e)

    @staticmethod
    def decode_and_decompress(data):
        compressed_data = base64.b64decode(data)
        return zlib.decompress(compressed_data).decode()
