"""Device connection and operations"""
import datetime
import os
from time import sleep
from threading import Event, Thread

from multipledispatch import dispatch

import utils
from device_module.device import BaseDevice
from modules import consts as modules_consts
from modules.deferred_messages.deferred_messages import DeferredMessages
from dispatcher_module.event_dispatcher import messages
from dispatcher_module.events import device_events
from api_gate.models import TransitQueue, VehicleCounter
from drivers.gate_loop.operations import *
from tolls_raspberry_proj import settings
from dispatcher_module.events.radar_events import RadarStateMachineEvent
from drivers.gate_loop import consts as radar_consts
from state_machine.radar_state_machine import RadarStateMachine
from dispatcher_module.events.antenna_events import AntennaStateMachineEvent
from modules import post_event
from dispatcher_module.events.camera_events import CameraStateMachineEvent


from logger import get_logger
logger = get_logger()

if not settings.SIMULATE_PORTS:
    # noinspection PyUnresolvedReferences
    import RPi.GPIO as GPIO


class GateLoop(BaseDevice):
    device_automata = None
    _status = radar_consts.DISCONNECTED
    _stop_signal = None

    device_status_thread = None
    radar_state_thread = None
    serial_conn = None
    state_machine = None

    def __init__(self, name, uid, config):
        super().__init__(name, uid, config)

        self.message_view_data = None
        self.message_view_state = None

        self.current_operation = {}
        self.is_valid_config = None
        self.enable = False
        self.device_name = name

        self.detection_start_time = None

        if not settings.SIMULATE_PORTS:
            self.gate_loop = settings.GATE_LOOP_PIN
            GPIO.setmode(GPIO.BCM)                                          # choose BCM or BOARD
            GPIO.setup(self.gate_loop, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

        self.timeout = 100
        self.is_valid_config = True

        state_machine = config.get('bsm', 'gate-loop-bsm.json')
        self.is_valid_config = True

        try:
            bsm_def = utils.load_json(os.path.join(settings.CONFIG_PATH, state_machine))
        except Exception as e:
            logger.error(f'ERROR loading the arm_controller bsm config. The exception is {e}')
            bsm_def = {}

        self.device_automata = RadarStateMachine(self, bsm_def)

    def init_module(self):
        super(GateLoop, self).init_module()

    @property
    def is_enable(self):
        return self.enable

    @is_enable.setter
    def is_enable(self, value):
        self.enable = value

    def on_module_start(self):
        super(GateLoop, self).on_module_start()
        self._stop_signal = Event()

        try:
            self.device_status_thread = Thread(name=f'{self.device_name}', target=self.serial_radar_worker)
            sleep(0.2)
            self.device_status_thread.start()
            if not settings.SIMULATE_PORTS:
                self.radar_state_thread = Thread(name=f'arm_controller status', target=self.status_reader)
                sleep(0.2)
                self.radar_state_thread.start()

        except Exception as msg:
            print(f'Reader not initialized due to ${msg}')
            return False
        return True

    def on_module_stop(self):
        super(GateLoop, self).on_module_stop()
        self.module_status = modules_consts.MOD_ST_STOPPED

        if self._stop_signal:
            self._stop_signal.set()
            self.device_status_thread.join()
            self.device_status_thread = None
            self._stop_signal = None
        else:
            logger.error(messages.MODULE_WAS_STOPPED_ALREADY_FMT.format(self.device_name))

        return True

    def set_message_view_data(self, message, message_type):
        # will be displayed on the /processing and /error pages and will be auto-reset on changing to a different state
        self.message_view_data = {
            'message': message,
            'type': message_type
        }

        # noinspection PyUnresolvedReferences
        self.message_view_state = self.state

    def on_enter_init(self):
        pass

    def on_enter_process_radar_operation(self):
        # noinspection PyUnresolvedReferences
        logger.info(f'Entering state="{self.state}"')
        self.set_message_view_data('Procesando operaci�n... Por favor Espere', None)

    def on_radar_added(self):
        self._status = radar_consts.CONNECTED
        device_info = {
            'device_name': self.device_name,
            'device_type': self.device_type
        }
        # noinspection PyTypeChecker
        self.post_event(device_events.DeviceConnectedEvent(self.module_uid, device_info))

    def on_radar_removed(self):
        self._status = radar_consts.DISCONNECTED
        payload = {}
        # noinspection PyTypeChecker
        self.device_automata.dispatch(radar_consts.EV_DEVICE_REMOVED, payload)
        device_info = {
            'device_name': self.device_name,
            'device_type': self.device_type
        }
        self.post_event(device_events.DeviceDisconnectedEvent(self.module_uid, device_info))

    def on_enter_vehicle_detected(self):
        self.detection_start_time = datetime.datetime.now()

    def on_enter_vehicle_passed(self):
        post_event(AntennaStateMachineEvent('backend', data={'trigger': 'ev_operative'}))
        post_event(CameraStateMachineEvent('backend', data={'trigger': 'ev_take_image'}))
        transit_message: TransitQueue = TransitQueue.objects.filter(status='WAITING').first()
        operation_mode = get_operation_mode(transit_message)
        try:
            counter = VehicleCounter.objects.get(name=operation_mode)
        except VehicleCounter.DoesNotExist:
            counter = VehicleCounter.objects.create(name=operation_mode)

        counter.vehicle_count += 1
        counter.save()

        detection_time = datetime.datetime.now() - self.detection_start_time
        transit = get_transit(transit_message, detection_time)

        message_type = get_message_type_receiver()

        if not DeferredMessages.post_deferred_message(message_type, transit):
            logger.error(f'Error in on_enter_vehicle_passed while posting the transit message')

        self.device_automata.dispatch(radar_consts.EV_NON_VEHICLE_DETECT)

    def on_enter_non_vehicle_detected(self):
        self.detection_start_time = None

    # noinspection PyUnusedLocal, PyUnresolvedReferences
    def update_device_status(self, data):
        print('Reader state ->', self.state)
        pass

    def on_display_message(self, message_data):
        pass

    def on_message_time_out(self, event_data):
        pass

    def on_operation_success(self, result):
        pass

    # Events
    @dispatch(RadarStateMachineEvent)
    def do_dispatch_event(self, event):
        request_data = event.data
        trigger = request_data.get(radar_consts.TRIGGER)
        if self.device_automata.dispatch(trigger, request_data):
            logger.debug(f'Event --> {event.name} dispatched')

    def serial_radar_worker(self, interval=0.25):
        sleep(0.2)
        while self._stop_signal and not self._stop_signal.is_set():
            # noinspection PyUnresolvedReferences
            if self.state == radar_consts.ST_IDLE:
                response = None
                status = radar_consts.DISCONNECTED if response is radar_consts.DEVICE_NOT_CONNECTED \
                    else radar_consts.CONNECTED
                if status != self._status:
                    self._status = status
                    if self._status == radar_consts.CONNECTED:
                        self.on_radar_added()
                    else:
                        self.on_radar_removed()

            self._stop_signal.wait(interval)

    # noinspection PyUnresolvedReferences
    def status_reader(self):
        while self._stop_signal and not self._stop_signal.is_set():
            sleep(0.5)
            vehicle_in_loop = (GPIO.input(self.gate_loop) == 0)

            if self.state == "st_non_vehicle_detected" and vehicle_in_loop:
                logger.info(f"Vehicle present in Exit Loop ---> {vehicle_in_loop}")
                self.device_automata.dispatch(radar_consts.EV_VEHICLE_DETECTED)

            elif self.state == "st_vehicle_detected" and not vehicle_in_loop:
                logger.info(f"Vehicle present in Exit Loop ---> {vehicle_in_loop}")
                self.device_automata.dispatch(radar_consts.EV_VEHICLE_PASSED)
